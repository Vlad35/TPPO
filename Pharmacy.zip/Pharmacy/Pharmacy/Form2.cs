﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Pharmacy
{
    public partial class Form2 : Form
    {
        private NpgsqlConnection oCon;
        private string connection;
        private string nameOfMedicine;
        private int price;
        private string name;
        private string status;
        private int id_medicine;
        public int client_id = -1;
        public int check_id = -1;
        public bool flag = true;
        public DateTime thisDay = DateTime.Today;
        string filePath = "D:/Clients.txt";

        public Form2(NpgsqlConnection oCon, string connection)
        {
            InitializeComponent();
            this.oCon = oCon;
            this.connection = connection;
            erase();
        }

        private void erase()
        {
            NameOfMedicine.Text = "";
            nameOfMedicineBox.Text = "";
            priceOfMedicineBox.Text = "";
            statusOfMedicineBox.Text = "";
            InputClientsData.Visible = false;
            label2.Visible = false;
            MiddleNameBox.Visible = false;
            label7.Visible = false;
            label3.Visible = false;
            FirstNameBox.Visible = false;
            LastNameBox.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            BirthDate.Visible = false;
            PasportSeries.Visible = false;
            PasportNumber.Visible = false;
            OrderMedicine.Visible = false;
            Clear.Visible = false;
            WatchCheck.Visible = false;
            ReturnToOrdering.Visible = false;

        }
        private void eraseSale()
        {
            label1.Visible = false;
            NameOfMedicine.Visible = false;
            searchButton.Visible = false;
            NameOfMedicine.Visible = false;
            nameOfMedicineFromDB.Visible = false;
            nameOfMedicineBox.Visible = false;
            priceOfMedicineBox.Visible = false;
            priceOfMedicine.Visible = false;
            statusOfMedicine.Visible = false;
            statusOfMedicineBox.Visible = false;
            OK.Visible = false;
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            nameOfMedicine = NameOfMedicine.Text.ToString();
            string request = "SELECT * FROM Medicine_list WHERE name = @nameOfMedicine";

            using (NpgsqlCommand cmd = new NpgsqlCommand(request, oCon))
            {
                oCon.Open();
                cmd.Parameters.AddWithValue("@nameOfMedicine", nameOfMedicine);

                using (NpgsqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        id_medicine = Convert.ToInt32(dr["id_medicine"]);
                        name = dr["name"].ToString();
                    }
                }
            }

            request = "SELECT * FROM Medicines WHERE id_medicine = @id_medicine";

            using (NpgsqlCommand cmd2 = new NpgsqlCommand(request, oCon))
            {
                cmd2.Parameters.AddWithValue("@id_medicine", id_medicine);

                using (NpgsqlDataReader dr = cmd2.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        price = Convert.ToInt32(dr["price"]);
                        status = dr["status"].ToString();
                    }
                }
            }

            nameOfMedicineBox.Text = name;
            priceOfMedicineBox.Text = price.ToString();
            statusOfMedicineBox.Text = status;
        }

        private void OrderMedicine_Click(object sender, EventArgs e)
        {

            string last_name = LastNameBox.Text.ToString();
            string first_name = FirstNameBox.Text.ToString();
            string middle_name = MiddleNameBox.Text.ToString();
            string birth_date = BirthDate.Value.ToString().Substring(0, 10);
            int passport_series = Convert.ToInt32(PasportSeries.Text);
            int passport_number = Convert.ToInt32(PasportNumber.Text);

            client_id = search_cl(last_name, first_name, middle_name, birth_date, passport_series, passport_number);
            //searchClient(new Client(first_name,middle_name,last_name, birth_date,passport_series,passport_number));

            File.AppendAllText(filePath, client_id.ToString());
            if (client_id == -1)
            {
                string s_insert = string.Format("insert into clients(last_name, first_name, middle_name, birth_date, passport_series, passport_number) values('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')", last_name, first_name, middle_name, birth_date, passport_series, passport_number);
                oCon.Open();
                NpgsqlCommand cmd_ins = new NpgsqlCommand(s_insert, oCon);
                cmd_ins.ExecuteNonQuery();
                oCon.Close();
                client_id = search_cl(last_name, first_name, middle_name, birth_date, passport_series, passport_number);
                //searchClient(new Client(last_name, first_name, middle_name, birth_date, passport_series, passport_number));
            }

            if (flag)
            {

                string s_insert_check = string.Format("insert into checks(id_client, id_worker,date_of_formation,total_price) values('{0}', '{1}','{2}','{3}')", client_id,1, thisDay,this.price);
                oCon.Close();
                oCon.Open();
                NpgsqlCommand cmd_insert_check = new NpgsqlCommand(s_insert_check, oCon);
                cmd_insert_check.ExecuteNonQuery();
                oCon.Close();

                string searh_check = string.Format("select id_check from checks where id_client = '{0}' and date_of_formation = '{1}'", client_id, thisDay);
                oCon.Close();
                oCon.Open();
                NpgsqlCommand cmd_searh_check = new NpgsqlCommand(searh_check, oCon);

                using (NpgsqlDataReader dr = cmd_searh_check.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        check_id = Convert.ToInt32(dr["id_check"]);
                    }
                }
                oCon.Close();
                flag = false;
            }

            double price = 0;
            string s_price = string.Format("select price,status from medicines where id_medicine = '{0}'", id_medicine);
            oCon.Close();
            oCon.Open();
            NpgsqlCommand cmd_price = new NpgsqlCommand(s_price, oCon);
            using (NpgsqlDataReader dr = cmd_price.ExecuteReader())
            {
                while (dr.Read())
                {
                    price = Convert.ToInt32(dr["price"]);
                    status = dr["status"].ToString();
                }
            }
            oCon.Close();


            string s_insert_medicine = string.Format("insert into medicines(id_client,id_check,price,status) values('{0}', '{1}', '{2}', '{3}')", client_id, check_id, this.price, status);
            oCon.Close();
            oCon.Open();
            NpgsqlCommand cmd_insert_ticket = new NpgsqlCommand(s_insert_medicine, oCon);
            cmd_insert_ticket.ExecuteNonQuery();
            oCon.Close();

            Clear.Visible = true;
            WatchCheck.Visible = true;
        }

        public int search_cl(string last_name, string first_name, string middle_name, string birth_date, int passport_series, int passport_number)
        {
            string s_cl = string.Format("select id_client from clients where last_name = '{0}' and first_name = '{1}' and middle_name = '{2}' and birth_date = '{3}' and passport_series = '{4}' and passport_number= '{5}'", last_name, first_name, middle_name, birth_date, passport_series, passport_number);
            oCon.Close();
            oCon.Open();
            NpgsqlCommand cmd_cl = new NpgsqlCommand(s_cl, oCon);
            int id_cl = -1;
            using (NpgsqlDataReader dr = cmd_cl.ExecuteReader())
            {
                while (dr.Read())
                {
                    id_cl = Convert.ToInt32(dr["id_client"]);
                }
            }
            oCon.Close();
            return id_cl;
        }

        public class Client
        {
            public int id { get; set; }
            public string last_name { get; set; }

            public string first_name { get; set; }

            public string middle_name { get; set; }

            public string birth_date { get; set; }

            public int passport_series { get; set; }

            public int passport_number { get; set; }

            public Client() { }

            public Client(string first_name, string middle_name, string last_name, string birth_date, int passport_series, int passport_number)
            {
                this.first_name = first_name;
                this.middle_name = middle_name;
                this.last_name = last_name;
                this.birth_date = birth_date;
                this.passport_series = passport_series;
                this.passport_number = passport_number;
            }
        }

        private void ReturnToOrdering_Click(object sender, EventArgs e)
        {
            this.Close();
            NameOfMedicine.Visible = true;
            nameOfMedicineBox.Visible = true;
            priceOfMedicineBox.Visible = true;
            statusOfMedicineBox.Visible = true;
            label1.Visible = true;
            searchButton.Visible = true;
            nameOfMedicineFromDB.Visible = true;
            priceOfMedicineBox.Visible = true;
            priceOfMedicine.Visible = true;
            statusOfMedicineBox.Visible = true;
            statusOfMedicine.Visible = true;
            OK.Visible = true;

            InputClientsData.Visible = false;
            label2.Visible = false;
            MiddleNameBox.Visible = false;
            label7.Visible = false;
            label3.Visible = false;
            FirstNameBox.Visible = false;
            LastNameBox.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            BirthDate.Visible = false;
            PasportSeries.Visible = false;
            PasportNumber.Visible = false;
            OrderMedicine.Visible = false;
            Clear.Visible = false;
            WatchCheck.Visible = false;
            ReturnToOrdering.Visible = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void OK_Click(object sender, EventArgs e)
        {
            eraseSale();
            InputClientsData.Visible = true;
            label2.Visible = true;
            MiddleNameBox.Visible = true;
            label7.Visible = true;
            label3.Visible = true;
            FirstNameBox.Visible = true;
            LastNameBox.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            BirthDate.Visible = true;
            PasportSeries.Visible = true;
            PasportNumber.Visible = true;
            OrderMedicine.Visible = true;
            ReturnToOrdering.Visible = true;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            erase();
        }

        void UpdateGrid()
        {
            string SQL = string.Format("select  " +
                " medicines.id_client as mc1," +
                " medicines.price as pr," +
                "medicines.status as st" +
                ",clients.last_name as lname," +
                " clients.first_name as fname," +
                " clients.middle_name as mname," +
                " clients.birth_date as bdate\r\n " +
                "               from medicines" +
                " join clients on medicines.id_client = clients.id_client\r\n" +
                "           join checks on checks.id_client = clients.id_client\r\n" +
                "                where checks.id_check = '{0}'", check_id);

            NpgsqlDataAdapter da = new NpgsqlDataAdapter(SQL, connection);
            DataSet ds = new DataSet();
            System.Data.Common.DataTableMapping Map = da.TableMappings.Add("Checks", "Чеки");
            Map.ColumnMappings.Add("mc1", "Идентификатор Клиента");
            Map.ColumnMappings.Add("pr", "Цена");
            Map.ColumnMappings.Add("st", "Статус");
            Map.ColumnMappings.Add("lname", "Фамилия");
            Map.ColumnMappings.Add("fname", "Имя");
            Map.ColumnMappings.Add("mname", "Отчество");
            Map.ColumnMappings.Add("bdate", "Дата рождения");
            da.Fill(ds, "Checks");
            dataGridView1.DataSource = ds.Tables["Чеки"].DefaultView;

        }

        private void WatchCheck_Click_1(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            ReturnToOrdering.Visible = false;
            Clear.Visible = false;
            UpdateGrid();
        }
    }
}
