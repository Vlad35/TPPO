﻿namespace Pharmacy
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            NameOfMedicine = new TextBox();
            searchButton = new Button();
            nameOfMedicineFromDB = new Label();
            priceOfMedicine = new Label();
            statusOfMedicine = new Label();
            nameOfMedicineBox = new TextBox();
            priceOfMedicineBox = new TextBox();
            statusOfMedicineBox = new TextBox();
            ReturnToOrdering = new Button();
            WatchCheck = new Button();
            Clear = new Button();
            InputClientsData = new Label();
            OrderMedicine = new Button();
            PasportNumber = new MaskedTextBox();
            PasportSeries = new MaskedTextBox();
            LastNameBox = new TextBox();
            FirstNameBox = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            BirthDate = new DateTimePicker();
            label3 = new Label();
            label2 = new Label();
            label7 = new Label();
            MiddleNameBox = new TextBox();
            OK = new Button();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(215, 45);
            label1.Name = "label1";
            label1.Size = new Size(132, 20);
            label1.TabIndex = 0;
            label1.Text = "Покупка лекарств";
            // 
            // NameOfMedicine
            // 
            NameOfMedicine.Location = new Point(222, 102);
            NameOfMedicine.Name = "NameOfMedicine";
            NameOfMedicine.Size = new Size(125, 27);
            NameOfMedicine.TabIndex = 1;
            // 
            // searchButton
            // 
            searchButton.Location = new Point(231, 161);
            searchButton.Name = "searchButton";
            searchButton.Size = new Size(94, 29);
            searchButton.TabIndex = 2;
            searchButton.Text = "Найти";
            searchButton.UseVisualStyleBackColor = true;
            searchButton.Click += searchButton_Click;
            // 
            // nameOfMedicineFromDB
            // 
            nameOfMedicineFromDB.AutoSize = true;
            nameOfMedicineFromDB.Location = new Point(149, 234);
            nameOfMedicineFromDB.Name = "nameOfMedicineFromDB";
            nameOfMedicineFromDB.Size = new Size(39, 20);
            nameOfMedicineFromDB.TabIndex = 3;
            nameOfMedicineFromDB.Text = "Имя";
            // 
            // priceOfMedicine
            // 
            priceOfMedicine.AutoSize = true;
            priceOfMedicine.Location = new Point(149, 292);
            priceOfMedicine.Name = "priceOfMedicine";
            priceOfMedicine.Size = new Size(45, 20);
            priceOfMedicine.TabIndex = 4;
            priceOfMedicine.Text = "Цена";
            // 
            // statusOfMedicine
            // 
            statusOfMedicine.AutoSize = true;
            statusOfMedicine.Location = new Point(149, 352);
            statusOfMedicine.Name = "statusOfMedicine";
            statusOfMedicine.Size = new Size(52, 20);
            statusOfMedicine.TabIndex = 5;
            statusOfMedicine.Text = "Статус";
            // 
            // nameOfMedicineBox
            // 
            nameOfMedicineBox.Location = new Point(273, 232);
            nameOfMedicineBox.Name = "nameOfMedicineBox";
            nameOfMedicineBox.Size = new Size(125, 27);
            nameOfMedicineBox.TabIndex = 6;
            // 
            // priceOfMedicineBox
            // 
            priceOfMedicineBox.Location = new Point(273, 292);
            priceOfMedicineBox.Name = "priceOfMedicineBox";
            priceOfMedicineBox.Size = new Size(125, 27);
            priceOfMedicineBox.TabIndex = 7;
            // 
            // statusOfMedicineBox
            // 
            statusOfMedicineBox.Location = new Point(273, 349);
            statusOfMedicineBox.Name = "statusOfMedicineBox";
            statusOfMedicineBox.Size = new Size(125, 27);
            statusOfMedicineBox.TabIndex = 8;
            // 
            // ReturnToOrdering
            // 
            ReturnToOrdering.Location = new Point(830, 612);
            ReturnToOrdering.Margin = new Padding(3, 4, 3, 4);
            ReturnToOrdering.Name = "ReturnToOrdering";
            ReturnToOrdering.Size = new Size(112, 71);
            ReturnToOrdering.TabIndex = 42;
            ReturnToOrdering.Text = "Вернуться к оформлению лекарств";
            ReturnToOrdering.UseVisualStyleBackColor = true;
            ReturnToOrdering.Visible = false;
            ReturnToOrdering.Click += ReturnToOrdering_Click;
            // 
            // WatchCheck
            // 
            WatchCheck.Location = new Point(1009, 626);
            WatchCheck.Margin = new Padding(3, 4, 3, 4);
            WatchCheck.Name = "WatchCheck";
            WatchCheck.Size = new Size(145, 44);
            WatchCheck.TabIndex = 41;
            WatchCheck.Text = "Просмотреть чек";
            WatchCheck.UseVisualStyleBackColor = true;
            WatchCheck.Visible = false;
            WatchCheck.Click += WatchCheck_Click_1;
            // 
            // Clear
            // 
            Clear.BackColor = Color.Bisque;
            Clear.Font = new Font("Segoe UI", 14F);
            Clear.Location = new Point(1212, 626);
            Clear.Margin = new Padding(3, 4, 3, 4);
            Clear.Name = "Clear";
            Clear.Size = new Size(199, 48);
            Clear.TabIndex = 40;
            Clear.Text = "Очистить данные";
            Clear.UseVisualStyleBackColor = false;
            Clear.Visible = false;
            Clear.Click += Clear_Click;
            // 
            // InputClientsData
            // 
            InputClientsData.AutoSize = true;
            InputClientsData.Font = new Font("Segoe UI", 18F);
            InputClientsData.Location = new Point(832, 92);
            InputClientsData.Name = "InputClientsData";
            InputClientsData.Size = new Size(354, 41);
            InputClientsData.TabIndex = 39;
            InputClientsData.Text = "Введите данные клиента";
            // 
            // OrderMedicine
            // 
            OrderMedicine.BackColor = Color.FromArgb(255, 192, 192);
            OrderMedicine.Font = new Font("Segoe UI", 18F);
            OrderMedicine.Location = new Point(587, 500);
            OrderMedicine.Margin = new Padding(3, 4, 3, 4);
            OrderMedicine.Name = "OrderMedicine";
            OrderMedicine.Size = new Size(947, 93);
            OrderMedicine.TabIndex = 38;
            OrderMedicine.Text = "Заказать лекарство";
            OrderMedicine.UseVisualStyleBackColor = false;
            OrderMedicine.Click += OrderMedicine_Click;
            // 
            // PasportNumber
            // 
            PasportNumber.Location = new Point(1042, 436);
            PasportNumber.Margin = new Padding(3, 4, 3, 4);
            PasportNumber.Mask = "000000";
            PasportNumber.Name = "PasportNumber";
            PasportNumber.Size = new Size(63, 27);
            PasportNumber.TabIndex = 37;
            PasportNumber.ValidatingType = typeof(int);
            // 
            // PasportSeries
            // 
            PasportSeries.Location = new Point(1042, 383);
            PasportSeries.Margin = new Padding(3, 4, 3, 4);
            PasportSeries.Mask = "0000";
            PasportSeries.Name = "PasportSeries";
            PasportSeries.Size = new Size(63, 27);
            PasportSeries.TabIndex = 36;
            PasportSeries.ValidatingType = typeof(int);
            // 
            // LastNameBox
            // 
            LastNameBox.Location = new Point(1042, 271);
            LastNameBox.Margin = new Padding(3, 4, 3, 4);
            LastNameBox.Name = "LastNameBox";
            LastNameBox.Size = new Size(181, 27);
            LastNameBox.TabIndex = 35;
            // 
            // FirstNameBox
            // 
            FirstNameBox.Location = new Point(1042, 211);
            FirstNameBox.Margin = new Padding(3, 4, 3, 4);
            FirstNameBox.Name = "FirstNameBox";
            FirstNameBox.Size = new Size(181, 27);
            FirstNameBox.TabIndex = 34;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14F);
            label6.Location = new Point(838, 436);
            label6.Name = "label6";
            label6.Size = new Size(197, 32);
            label6.TabIndex = 33;
            label6.Text = "Номер паспорта";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14F);
            label5.Location = new Point(838, 376);
            label5.Name = "label5";
            label5.Size = new Size(190, 32);
            label5.TabIndex = 32;
            label5.Text = "Серия паспорта";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14F);
            label4.Location = new Point(838, 322);
            label4.Name = "label4";
            label4.Size = new Size(184, 32);
            label4.TabIndex = 31;
            label4.Text = "Дата рождения";
            // 
            // BirthDate
            // 
            BirthDate.Location = new Point(1042, 328);
            BirthDate.Margin = new Padding(3, 4, 3, 4);
            BirthDate.Name = "BirthDate";
            BirthDate.Size = new Size(228, 27);
            BirthDate.TabIndex = 30;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14F);
            label3.Location = new Point(838, 260);
            label3.Name = "label3";
            label3.Size = new Size(117, 32);
            label3.TabIndex = 29;
            label3.Text = "Отчество";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F);
            label2.Location = new Point(838, 160);
            label2.Name = "label2";
            label2.Size = new Size(113, 32);
            label2.TabIndex = 28;
            label2.Text = "Фамилия";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 14F);
            label7.Location = new Point(838, 207);
            label7.Name = "label7";
            label7.Size = new Size(61, 32);
            label7.TabIndex = 27;
            label7.Text = "Имя";
            // 
            // MiddleNameBox
            // 
            MiddleNameBox.Location = new Point(1042, 160);
            MiddleNameBox.Margin = new Padding(3, 4, 3, 4);
            MiddleNameBox.Name = "MiddleNameBox";
            MiddleNameBox.Size = new Size(181, 27);
            MiddleNameBox.TabIndex = 26;
            // 
            // OK
            // 
            OK.Location = new Point(304, 421);
            OK.Name = "OK";
            OK.Size = new Size(94, 29);
            OK.TabIndex = 44;
            OK.Text = "OK";
            OK.UseVisualStyleBackColor = true;
            OK.Click += OK_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(587, 45);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(975, 660);
            dataGridView1.TabIndex = 45;
            dataGridView1.Visible = false;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1736, 998);
            Controls.Add(dataGridView1);
            Controls.Add(OK);
            Controls.Add(ReturnToOrdering);
            Controls.Add(WatchCheck);
            Controls.Add(Clear);
            Controls.Add(InputClientsData);
            Controls.Add(OrderMedicine);
            Controls.Add(PasportNumber);
            Controls.Add(PasportSeries);
            Controls.Add(LastNameBox);
            Controls.Add(FirstNameBox);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(BirthDate);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label7);
            Controls.Add(MiddleNameBox);
            Controls.Add(statusOfMedicineBox);
            Controls.Add(priceOfMedicineBox);
            Controls.Add(nameOfMedicineBox);
            Controls.Add(statusOfMedicine);
            Controls.Add(priceOfMedicine);
            Controls.Add(nameOfMedicineFromDB);
            Controls.Add(searchButton);
            Controls.Add(NameOfMedicine);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox NameOfMedicine;
        private Button searchButton;
        private Label nameOfMedicineFromDB;
        private Label priceOfMedicine;
        private Label statusOfMedicine;
        private TextBox nameOfMedicineBox;
        private TextBox priceOfMedicineBox;
        private TextBox statusOfMedicineBox;
        private Button ReturnToOrdering;
        private Button WatchCheck;
        private Button Clear;
        private Label InputClientsData;
        private Button OrderMedicine;
        private MaskedTextBox PasportNumber;
        private MaskedTextBox PasportSeries;
        private TextBox LastNameBox;
        private TextBox FirstNameBox;
        private Label label6;
        private Label label5;
        private Label label4;
        private DateTimePicker BirthDate;
        private Label label3;
        private Label label2;
        private Label label7;
        private TextBox MiddleNameBox;
        private Button OK;
        private DataGridView dataGridView1;
    }
}