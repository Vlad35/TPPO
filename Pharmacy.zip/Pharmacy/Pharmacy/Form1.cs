using Npgsql;

namespace Pharmacy
{
    public partial class Form1 : Form
    {
        public NpgsqlConnection oCon;
        public string connection;
        public Form1()
        {
            InitializeComponent();
        }

        private void SaleButton_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=password; Database=tppo;";
            oCon = new NpgsqlConnection(connection);
            Form2 form2 = new Form2(oCon, connection);
            form2.Show();
        }
    }
}
